
import React, { useEffect, useState } from "react";
const Header = () => {
    const [url, setUrl] = useState(null)

    useEffect(() => {
        var url = window.location.href;
        if(url.includes('checkDominance')) {
            setUrl('checkDominance')
        }
        else {
            setUrl('')
        }
    })

    return (

        <div className='header'>
            {
              url === 'checkDominance'  ?
              <div className='text-header text-light'> Check Dominance </div>
              :
              <div className='text-header text-light'> Compare Crypto </div> 
            }
            {/* <div className='text-header text-light'> Compare Crypto </div> */}
        </div>

    )
}

export default Header