import React, { useEffect, useState, useMemo } from "react";
import { useDispatch, useSelector } from "react-redux";
import { checkUploadedFile } from "../../store/dominance/checkDominance";
import { checkDominance, dominanceDetailSuccess  } from "../../store/dominance/checkDominance";
import Table from 'react-bootstrap/Table';
import BarChart from 'react-bar-chart';


/**
 * @returns html
 */
const CheckDominance = () => {
    const dispatch = useDispatch();
    const [fileItem, setFileItem] = useState([])
    const [list, selectedList] = useState([])
    const [ file_state, setFileState ] = useState([])
    const [ dominanceResult, setDominanceResult ] = useState({})    
    const dominanceDetail = useSelector(({ dominance }) => dominance?.dominanceDetail)

    useEffect(() => {
        dispatch(dominanceDetailSuccess(null))
        selectedList([])
    }, [dispatch])

    const handleFileUpload = (string, results) => {
        const files = string?.target?.files;
        var all_files =[]
        for (let i =0 ;i<files.length;i++) {
            all_files.push(files[i])
        }
        setFileItem(all_files)
    }

    const checkNow = () => {
        if(fileItem) {
            dispatch(checkUploadedFile(fileItem))
        }
    }
    const margin = {top: 50, right: 20, bottom: 50, left: 40};

SECRET_KEY='SG-kjsdfhskfj87643rmenbfjsdbnf38746873877687368'
    function OptimizationDetail(data) {  
        if(data) {
            return (
            <tr> 
                <td>              
                <span className="result" style={{'display':'block', 'textAlign': 'center'}}>File : {data?.data?.fileName}</span>
                <br />
                    <span className="result">Optimization :</span>
                        <ul className="feature-list" style={{'color': '#9f9090'}}>
                            {Object.entries(data?.data?.optimization).map(([k,v], index) => (
                                <li key={index}>{v}</li>
                            ))}                                        
                        </ul>
                    { data?.data?.rated ?
                        <>
                            <span className="result">Rating :</span>
                            <ul className="feature-list" style={{'color': '#9f9090'}}>
                                {data?.data?.rated}
                            </ul>
                        </>
                        :
                            ''
                    }
                    <span className="result">Time Consumed :</span>
                        <ul className="feature-list" style={{'color': '#9f9090'}}>
                            {data?.data?.time} seconds
                        </ul>
                </td>
            </tr>
            )
        }
      }

      const CHART_COLORS = ["#e35b2c", "#e77235", "#eb8a40"];

    function Visualization(data) {
        console.log("---------- -data",data)
       
       return( <BarChart ylabel='Time(0-1s)'
                  width={500}
                  height={500}
                  margin={margin}
                  data={data?.data}
                />
       )

    }
    

    return (
        <div className="">
            <div className="comparsion-tbl-wrap">
                <div className="searchbar-wrapper">
                    <div className="search-box" style={{'color': '#9f9090'}} >
                    <input
                        type="file"
                        style={{
                            border: '1px solid #D1D1D1',
                            borderRadius: '15px',
                        }}
                        multiple="multiple"
                        onChange={handleFileUpload}
                    />
                    </div>
                    <div className="search-action">
                        <button type="button" onClick={() => checkNow()} className="btn btn-primary ">Check Now</button>
                    </div>
                </div>
                {dominanceDetail?.result?.fileType === 'js' ?
                    <Table className="comparsion-table text-light" >
                        <thead> Code Optimization Result: <br /> </thead>
                        <tbody>
                            <OptimizationDetail data ={dominanceDetail?.result}  />
                        </tbody>
                    </Table>
                :
                    ''
                }
                {dominanceDetail?.result?.fileType === 'zip' ?
                    <Table className="comparsion-table text-light" >
                        <thead> 
                            Code Optimization Result:    
                            <br />
                            {dominanceDetail?.result?.visualization_data[0]?.value ? 'yesssssss' : 'noooooooooooooo'}
                            <div style={{background: '#775af8', textAlign: 'center'}}>
                                <Visualization data ={dominanceDetail?.result?.visualization_data} />                             
                            </div>
                        </thead>
                        <tbody>                            
                            {Object.entries(dominanceDetail?.result?.optimization)?.map(([k,v], index) => (
                                <OptimizationDetail data={v} />
                            ))}
                        </tbody>
                    </Table>
                :
                    ''
                }
                {dominanceDetail?.result?.fileType === 'multi' ?
                    <Table className="comparsion-table text-light" >
                        <thead> 
                            Code Optimization Result: 
                            <br />
                            <div style={{background: '#775af8', textAlign: 'center'}}>
                                <Visualization data ={dominanceDetail?.result?.visualization_data} />                             
                            </div>                               
                        </thead>
                        <tbody> 
                        {dominanceDetail?.result?.optimization?.map((res, index) => (

                            res?.fileType === 'js' ?
                                <OptimizationDetail data ={res}  />
                            :
                            res?.fileType === 'zip' ?
                                Object.entries(res?.optimization)?.map(([k,v], index1) => (
                                        // console.log("---------k", k, 'vvvvvvvv', v)
                                        <OptimizationDetail data={v} />
                                ))
                            :
                            ''                           

                        ))}
                        </tbody>
                    </Table>
                :
                    ''
                }              
            </div>
        </div>
    )
}

export default CheckDominance
