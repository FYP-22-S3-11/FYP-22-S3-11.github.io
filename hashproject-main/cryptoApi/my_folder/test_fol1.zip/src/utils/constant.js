/**
 * Define all constant value
 */
