import HashService from './hashService';

export default HashService;
