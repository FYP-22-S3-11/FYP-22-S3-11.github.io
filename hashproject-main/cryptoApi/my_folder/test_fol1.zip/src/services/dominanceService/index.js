import DominanceService from './dominanceService';

export default DominanceService;
