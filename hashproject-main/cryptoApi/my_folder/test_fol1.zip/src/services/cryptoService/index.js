import CryptoService from './cryptoService';

export default CryptoService;
