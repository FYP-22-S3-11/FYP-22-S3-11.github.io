Change Log

12-09-2022
    
    Add readme file.

15-09-2022
    
    Update the forntend according to new database and api change show the detail.
    Update the build. 

16-09-2022
    Handle response and add validation message.
    Update the build server.
